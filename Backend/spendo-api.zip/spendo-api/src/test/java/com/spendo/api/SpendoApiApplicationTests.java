package com.spendo.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpendoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
